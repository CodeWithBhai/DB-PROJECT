package com.example.eod.Fragments;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.eod.Task.MainAdapter;
import com.example.eod.Task.OnPdfSelecterListner;
import com.example.eod.Task.OpenPdfActivity;
import com.example.eod.R;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements OnPdfSelecterListner {
    private MainAdapter adapter;
    private List<File> pdfList;
    private RecyclerView pdfRecyclerView;

    public HomeFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        pdfRecyclerView = view.findViewById(R.id.pdfRecyclerView);
        runTimePermission();
        return view;
    }

    private void runTimePermission(){
        Dexter.withContext(getContext()).withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        pdfDisplay();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                        Toast.makeText(getActivity(), "Permission denied!!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                }).check();
    }

    public ArrayList<File> findPdf (File file){
        ArrayList<File> fileArrayList = new ArrayList<>();
        File[] files = file.listFiles();

        for (File singleFile: files){
            if (singleFile.isDirectory() && !singleFile.isHidden()){
                fileArrayList.addAll(findPdf(singleFile));
            }else {
                if (singleFile.getName().endsWith(".PDF")){
                    fileArrayList.add(singleFile);
                }
            }
        }
        return fileArrayList;
    }

    public void pdfDisplay(){
        pdfRecyclerView.setHasFixedSize(true);
        pdfRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        pdfList = new ArrayList<>();
        pdfList.addAll(findPdf(Environment.getExternalStorageDirectory()));
        adapter = new MainAdapter(getContext(), pdfList, this);
        pdfRecyclerView.setAdapter(adapter);

    }

    @Override
    public void OnPdfelected(File file) {
        startActivity(new Intent(getActivity(), OpenPdfActivity.class).putExtra("path", file.getAbsolutePath()));
    }
}