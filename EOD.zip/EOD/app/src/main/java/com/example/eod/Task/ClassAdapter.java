package com.example.eod.Task;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eod.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class ClassAdapter extends FirebaseRecyclerAdapter<DataModels, ClassAdapter.myViewHolder> {

    public ClassAdapter(@NonNull FirebaseRecyclerOptions<DataModels> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myViewHolder holder, int position, @NonNull DataModels model) {
        holder.topicsID.setText(model.getTopicName());
        holder.thubnailID.setText(model.getThumbnail());
        holder.nameID.setText(model.getName());


        holder.subjectImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(holder.subjectImg.getContext(), FDFViewActivity.class);
                intent.putExtra("filename", model.getThumbnail());
                intent.putExtra("fileurl", model.getOnlineLink());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                holder.subjectImg.getContext().startActivity(intent);
            }
        });
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new myViewHolder(view);
    }

    public class myViewHolder extends RecyclerView.ViewHolder{
        ImageView subjectImg;
        TextView thubnailID, topicsID, nameID;

        public myViewHolder(@NonNull View itewView){
            super(itewView);
            subjectImg = itewView.findViewById(R.id.subjectImg);
            thubnailID = itewView.findViewById(R.id.thubnailID);
            topicsID = itewView.findViewById(R.id.topicsID);
            nameID = itewView.findViewById(R.id.nameID);
        }
    }
}
