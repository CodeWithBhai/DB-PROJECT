package com.example.eod.CRUD;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.eod.CRUD.Utils.SQLiteHelper;
import com.example.eod.R;
import com.example.eod.databinding.ActivityCrudMainBinding;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;

public class CrudMainActivity extends AppCompatActivity {
    ActivityCrudMainBinding binding;
    final int REQUEST_GALLERY =999;
    public static SQLiteHelper sqLiteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCrudMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //creating database
        sqLiteHelper = new SQLiteHelper(this, "RECORDDB.sqlite", null, 1);

        //creating table in the database
        sqLiteHelper.queryData("CREATE TABLE IF NOT EXISTS RECORD(id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR, price VARCHAR, descriptions VARCHAR, image BLOB)");


        binding.cameraImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(CrudMainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE
                }, REQUEST_GALLERY);
            }
        });
        binding.submitData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    sqLiteHelper.insertData(
                            binding.name.getText().toString().trim(),
                            binding.price.getText().toString().trim(),
                            binding.descriptions.getText().toString().trim(),
                            imageViewToByte(binding.cameraImg)
                    );
                    Toast.makeText(CrudMainActivity.this, "Added successfully!!", Toast.LENGTH_SHORT).show();
                    binding.name.setText("");
                    binding.descriptions.setText("");
                    binding.price.setText("");
                    binding.cameraImg.setImageResource(R.drawable.ic_baseline_camera_alt_24);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        binding.ListData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CrudMainActivity.this, AllRecordListActivity.class);
                startActivity(intent);
            }
        });
    }

    public static byte[] imageViewToByte(ImageView cameraImg) {
        Bitmap bitmap = ((BitmapDrawable) cameraImg.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] bytesArray = stream.toByteArray();
        return bytesArray;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_GALLERY){
            if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                //gallery intent
                Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/*");
                startActivityForResult(gallery, REQUEST_GALLERY);
            }
            else {
                Toast.makeText(this, "Don't have permission to access file location", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_GALLERY && resultCode == RESULT_OK){
            Uri imageUrl = data.getData();
            CropImage.activity(imageUrl)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK){
                Uri resultUrl = result.getUri();
                binding.cameraImg.setImageURI(resultUrl);
            }
            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Exception error = result.getError();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}