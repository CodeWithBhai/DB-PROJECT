package com.example.eod.Task;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.eod.R;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.PlayerView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;
import com.vimeo.networking.Configuration;
import com.vimeo.networking.VimeoClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class VideoPlayerActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String VIMEO_ACCESS_TOKEN = "access token";
    private static final String VIMDEO_ID = "417774698";

    private PlayerView playerView;
    private SimpleExoPlayer player;

    //Release references
    private boolean playWhenReady = false; //If true the player auto play the media
    private int currentWindow = 0;
    private long playbackPosition = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        playerView = findViewById(R.id.video_view);
        Button playBtn = findViewById(R.id.button2);

        playBtn.setOnClickListener(this);

        //Build vimeo configuration
        configVimeoClient();
    }

    private void createMediaItem(String url) {
        MediaItem mediaItem = MediaItem.fromUri(url);
        player.setMediaItem(mediaItem);
    }

    private void initializePlayer() {

        //To play streaming media, you need an ExoPlayer object.
        //SimpleExoPlayer is a convenient, all-purpose implementation of the ExoPlayer interface.
        player = new SimpleExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        callVimeoAPIRequest();

        //Supply the state information you saved in releasePlayer to your player during initialization.
        player.setPlayWhenReady(playWhenReady);
        player.seekTo(currentWindow, playbackPosition);
        player.prepare();
    }
    private void callVimeoAPIRequest() {

        String videolink = "https://player.vimeo.com/video/" + VIMDEO_ID +"/config";

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        //params.put("key", "value");
        //    params.put("more", "data");
        client.get(videolink, params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, String responseString, Throwable throwable) {

            }

            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, String responseString) {
                try {

                    JSONObject jsonObject = new JSONObject(responseString);
                    JSONObject req = jsonObject.getJSONObject("request");
                    JSONObject files = req.getJSONObject("files");
                    JSONArray progressive = files.getJSONArray("progressive");

                    JSONObject array1 = progressive.getJSONObject(1);
                    String v_url=array1.getString("url");

                    Log.d("URLL ",v_url);

                    createMediaItem(v_url);

                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
                }
        );
    }

    private void configVimeoClient() {
        Configuration.Builder configBuilder =
                new Configuration.Builder(VideoPlayerActivity.VIMEO_ACCESS_TOKEN) //Pass app access token
                        .setCacheDirectory(this.getCacheDir());
        VimeoClient.initialize(configBuilder.build());
    }

    @Override
    public void onClick(View v) {
        player.setPlayWhenReady(true);
    }

    @Override
    public void onStart() {
        super.onStart();
        initializePlayer();
    }

}
