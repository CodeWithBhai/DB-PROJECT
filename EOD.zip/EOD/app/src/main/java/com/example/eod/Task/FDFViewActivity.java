package com.example.eod.Task;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.eod.R;

import java.net.URLEncoder;

public class FDFViewActivity extends AppCompatActivity {
    WebView webPdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fdfview);

        webPdf = findViewById(R.id.webPdf);

        String fileName = getIntent().getStringExtra("filename");
        String fileUrl = getIntent().getStringExtra("fileurl");

        ProgressDialog pdf = new ProgressDialog(this);
        pdf.setTitle(fileName);
        pdf.setMessage("Opening....");

        webPdf.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                pdf.show();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pdf.dismiss();
            }
        });

        String url ="";
        try {
            url = URLEncoder.encode(fileUrl, "UTF-8");
        }catch (Exception exception){
            exception.printStackTrace();
        }
        webPdf.loadUrl("http://docs.google.com/gview?embedded=true&url" + url);
    }
}