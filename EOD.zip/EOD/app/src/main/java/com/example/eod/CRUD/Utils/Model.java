package com.example.eod.CRUD.Utils;

public class Model {
    private int id;
    private String name, price, descriptions, photo;
    private byte[] image;


    public Model(int id, String name, String price, String descriptions, String photo, byte[] image) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.descriptions = descriptions;
        this.photo = photo;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDesc() {
        return descriptions;
    }

    public void setDesc(String descriptions) {
        this.descriptions = descriptions;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
