package com.example.eod.Task;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.example.eod.databinding.ActivityRegisterBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    ActivityRegisterBinding binding;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        binding.submitArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createUser();
            }
        });
        binding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });

    }

    private void createUser() {
        String emai = binding.emailID.getText().toString();
        String password = binding.password.getText().toString();
        String name = binding.name.getText().toString();
        String boardName = binding.board.getText().toString();
        String className = binding.classname.getText().toString();

        if (TextUtils.isEmpty(emai)){
            binding.emailID.setError("Email cannot be empty");
            binding.emailID.requestFocus();
        }else if (TextUtils.isEmpty(password)){
            binding.password.setError("Password cannot be empty");
            binding.password.requestFocus();
        }else if (TextUtils.isEmpty(name)){
            binding.name.setError("name cannot be empty");
        }else if (TextUtils.isEmpty(boardName)){
            binding.board.setError("Board cannot be empty");
        }else if (TextUtils.isEmpty(className)){
            binding.classname.setError("Class cannot be empty");
        }else {
            auth.createUserWithEmailAndPassword(emai, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(RegisterActivity.this, "User register successfully!!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                    }else {
                        Toast.makeText(RegisterActivity.this, "Registration error!!"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}