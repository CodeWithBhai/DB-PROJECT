package com.example.eod.Task;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.eod.R;
import com.example.eod.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    FirebaseAuth firebaseAuth;
    private List<ModelClass> viewItem = new ArrayList<>();
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerViewAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        firebaseAuth = FirebaseAuth.getInstance();

        binding.logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
            }
        });
/*        layoutManager = new LinearLayoutManager(this);
        binding.empRecyclerView.setLayoutManager(layoutManager);
        adapter = new RecyclerViewAdapter( viewItem, this);
        binding.empRecyclerView.setAdapter(adapter);*/

        addItemFromJson();
    }

    private void addItemFromJson() {
        try {
            String jsonDataString = readJsonDataFromFile();
            JSONArray jsonArray = new JSONArray(jsonDataString);
            for (int i=0;i<jsonArray.length();i++){
                JSONObject itemObject = jsonArray.getJSONObject(i);
                String name = itemObject.getString("subjects");
                String topicName = itemObject.getString("topics");

             /*   ModelClass modelClass = new ModelClass(name, topicName);
                viewItem.add(modelClass);*/
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private String readJsonDataFromFile() throws IOException {
        InputStream inputStream = null;
        StringBuffer stringBuffer = new StringBuffer();

        try {
            String jsonString = null;
            inputStream = getResources().openRawResource(R.raw.demo);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));

            while ((jsonString = bufferedReader.readLine()) !=null){
                stringBuffer.append(jsonString);
            }
        }finally {
            if (inputStream!= null){
                inputStream.close();
            }
        }
        return new String(stringBuffer);
    }
/*
    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user == null){
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        }
    }*/
}