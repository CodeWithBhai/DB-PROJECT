package com.example.eod.Task;

public class DataModels {
    String name, offlineLink, onlineLink,thumbnail,topicName;

    public DataModels() {
    }

    public DataModels(String name, String offlineLink, String onlineLink, String thumbnail, String topicName) {
        this.name = name;
        this.offlineLink = offlineLink;
        this.onlineLink = onlineLink;
        this.thumbnail = thumbnail;
        this.topicName = topicName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOfflineLink() {
        return offlineLink;
    }

    public void setOfflineLink(String offlineLink) {
        this.offlineLink = offlineLink;
    }

    public String getOnlineLink() {
        return onlineLink;
    }

    public void setOnlineLink(String onlineLink) {
        this.onlineLink = onlineLink;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }
}
