package com.example.eod.ChatGPT.Model;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eod.R;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MyViewHolder> {

    List<ChatModel> messageList;

    public MessageAdapter(List<ChatModel> messageList) {
        this.messageList = messageList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View chatView = LayoutInflater.from(parent.getContext()).inflate(R.layout.left_chat_layout, null);
        MyViewHolder myViewHolder = new MyViewHolder(chatView);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
ChatModel message = messageList.get(position);
if (message.getSentBy().equals(ChatModel.SENT_BY_ME)){
    holder.left_chat_view.setVisibility(View.GONE);
    holder.right_chat_view.setVisibility(View.VISIBLE);
    holder.right_chat.setText(message.getMessage());
}else {
    holder.right_chat_view.setVisibility(View.GONE);
    holder.left_chat_view.setVisibility(View.VISIBLE);
    holder.left_chat.setText(message.getMessage());
}
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        LinearLayout left_chat_view, right_chat_view;
        TextView left_chat, right_chat;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);

            left_chat_view = itemView.findViewById(R.id.left_chat_view);
            right_chat_view = itemView.findViewById(R.id.right_chat_view);
            left_chat = itemView.findViewById(R.id.left_chat);
            right_chat = itemView.findViewById(R.id.right_chat);
        }
    }
}
