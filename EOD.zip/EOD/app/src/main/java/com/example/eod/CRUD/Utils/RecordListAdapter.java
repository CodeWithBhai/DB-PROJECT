package com.example.eod.CRUD.Utils;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;

import com.example.eod.CRUD.AllRecordListActivity;
import com.example.eod.CRUD.CrudMainActivity;
import com.example.eod.CRUD.FullImageActivity;
import com.example.eod.R;

import java.util.ArrayList;

public class RecordListAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private ArrayList<Model> recordList;

    public RecordListAdapter(Context context, int layout, ArrayList<Model> recordList) {
        this.context = context;
        this.layout = layout;
        this.recordList = recordList;
    }

    @Override
    public int getCount() {
        return recordList.size();
    }

    @Override
    public Object getItem(int position) {
        return recordList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        ImageView imageID;
        TextView nameShow, descriptionShow, priceShow, delete, update;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        ViewHolder holder = new ViewHolder();

        if (row==null){
            LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = layoutInflater.inflate(layout, null);

            holder.nameShow = row.findViewById(R.id.nameShow);
            holder.priceShow = row.findViewById(R.id.priceShow);
            holder.descriptionShow = row.findViewById(R.id.descriptionShow);
            holder.imageID = row.findViewById(R.id.imageID);
            holder.delete = row.findViewById(R.id.delete);
            holder.update = row.findViewById(R.id.update);



            row.setTag(holder);
        }else {
            holder = (ViewHolder) row.getTag();
        }

        Model model = recordList.get(position);
        int modelId = model.getId();
        holder.nameShow.setText(model.getName());
        holder.priceShow.setText(model.getPrice());
        holder.descriptionShow.setText(model.getDesc());

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c = CrudMainActivity.sqLiteHelper.getData("SELECT id FROM RECORD");
                ArrayList<Integer> arrayId = new ArrayList<Integer>();
                while (c.moveToNext()){
                    arrayId.add(c.getInt(0));
                }
                showDialogDelete(arrayId.get(position));
            }
        });

        byte[] recordImage = model.getImage();
            Bitmap bitmap = BitmapFactory.decodeByteArray(recordImage, 0, recordImage.length);
            holder.imageID.setImageBitmap(bitmap);
            String imageBitMap = bitmap.toString();

        holder.imageID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, FullImageActivity.class);
                intent.putExtra("imageId", imageBitMap);
                context.startActivity(intent);
            }
        });

        holder.update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Long Press for Update", Toast.LENGTH_LONG).show();
            }
        });

        return row;
    }

    private void showDialogDelete(int idRecord) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Warning!!");
        builder.setMessage("Are you sure to delete?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    CrudMainActivity.sqLiteHelper.deleteData(idRecord);
                    Toast.makeText(context, "Delete Successfully!!", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();

    }
}
