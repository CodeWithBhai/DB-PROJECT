package com.example.eod.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.eod.Task.ClassAdapter;
import com.example.eod.Task.DataModels;
import com.example.eod.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class BlacnkPdfFragment extends Fragment {
    ClassAdapter classAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        RecyclerView recyclerView;

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_blacnk_pdf, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        FirebaseRecyclerOptions<DataModels> options =
                new FirebaseRecyclerOptions.Builder<DataModels>().setQuery(FirebaseDatabase.getInstance().getReference().child("topics"), DataModels.class)
                .build();

        classAdapter = new ClassAdapter(options);
        recyclerView.setAdapter(classAdapter);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        classAdapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        classAdapter.stopListening();
    }
}