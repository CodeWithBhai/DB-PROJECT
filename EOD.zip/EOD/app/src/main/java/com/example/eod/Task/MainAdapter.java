package com.example.eod.Task;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eod.R;

import java.io.File;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {
    private Context context;
    private List<File> pdfFiles;
    OnPdfSelecterListner listner;

    public MainAdapter(Context context, List<File> pdfFiles, OnPdfSelecterListner listner) {
        this.context = context;
        this.pdfFiles = pdfFiles;
        this.listner = listner;
    }

    @NonNull
    @Override
    public MainAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.pdf_card_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MainAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.pdfName.setText(pdfFiles.get(position).getName());
        holder.pdfName.setSelected(true);

        holder.cardId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listner.OnPdfelected(pdfFiles.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return pdfFiles.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardId;
        ImageView pdfImage;
        TextView pdfName;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            pdfName = itemView.findViewById(R.id.pdfName);
            pdfImage = itemView.findViewById(R.id.pdfImage);
            cardId = itemView.findViewById(R.id.cardId);
        }
    }
}
