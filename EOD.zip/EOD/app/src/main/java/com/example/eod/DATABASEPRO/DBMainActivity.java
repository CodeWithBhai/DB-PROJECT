package com.example.eod.DATABASEPRO;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eod.R;
import com.example.eod.databinding.ActivityDbmainBinding;
import com.theartofdev.edmodo.cropper.CropImage;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DBMainActivity extends AppCompatActivity {
    ActivityDbmainBinding binding;
    private MyDBHelper dbMain;
    SQLiteDatabase sqLiteDatabase;
    ArrayList<ModelRecord> recordList = new ArrayList<>();
    ActionBar actionBar;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDbmainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dbMain = new MyDBHelper(this);

        actionBar = getSupportActionBar();
        actionBar.setTitle("All Records");
        loadRecordList();

        binding.addRecordbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddUpdateRecordActivity.class);
                startActivity(intent);
            }
        });

    }

    private void loadRecordList() {
        AdapterRecord adapterRecord = new AdapterRecord(DBMainActivity.this, dbMain.getAllRecord(Constants.C_ADDED_TIMESTAMP + " DESC"));
        binding.allShowItems.setAdapter(adapterRecord);
        actionBar.setSubtitle("Total: "+dbMain.getRecordCount());

    }

    private void searchRecords(String query){
        AdapterRecord adapterRecord = new AdapterRecord(this, dbMain.searchRecord(query));
        binding.allShowItems.setAdapter(adapterRecord);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchRecords(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchRecords(newText);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRecordList();
    }
}