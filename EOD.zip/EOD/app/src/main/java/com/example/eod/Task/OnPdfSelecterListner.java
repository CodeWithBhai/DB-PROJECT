package com.example.eod.Task;

import java.io.File;

public interface OnPdfSelecterListner {
    void OnPdfelected(File file);
}
