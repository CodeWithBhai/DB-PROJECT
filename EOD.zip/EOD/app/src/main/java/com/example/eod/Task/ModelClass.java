package com.example.eod.Task;

public class ModelClass {
    private static String Subject;
    private static String topic;

    public ModelClass() {
    }

    public static String getSubjects() {
        return Subject;
    }

    public static void setSubjects(String subjects) {
        ModelClass.Subject = subjects;
    }

    public static String getTopic() {
        return topic;
    }

    public static void setTopic(String topic) {
        ModelClass.topic = topic;
    }
}