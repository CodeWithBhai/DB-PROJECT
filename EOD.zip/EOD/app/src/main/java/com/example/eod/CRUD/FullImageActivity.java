package com.example.eod.CRUD;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.eod.DATABASEPRO.Constants;
import com.example.eod.DATABASEPRO.DBMain;
import com.example.eod.R;

import java.util.Calendar;
import java.util.Locale;

public class FullImageActivity extends AppCompatActivity {
    ImageView fullImage;
    private ActionBar actionBar;
    String recordImage;
    DBMain dbMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_image);

        actionBar = getSupportActionBar();
        actionBar.setTitle("Record Details");
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        fullImage = findViewById(R.id.fullImage);
        Intent intent = getIntent();
        recordImage = intent.getStringExtra("RECORD_ID");
        showRecord();

       // Toast.makeText(this, "show"+bitmap, Toast.LENGTH_SHORT).show();

        }

    private void showRecord() {
        String selectQuery = " SELECT * FROM " + Constants.TABLE_NAME + " WHERE " + Constants.C_IMAGE + "=\"" + recordImage + "\"";
        SQLiteDatabase db = dbMain.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()){
            do {
                @SuppressLint("Range")
                String imageShow = ""+ cursor.getString(cursor.getColumnIndex(Constants.C_IMAGE));
                @SuppressLint("Range")
                String timeStamp = ""+ cursor.getString(cursor.getColumnIndex(Constants.C_ADDED_TIMESTAMP));
                @SuppressLint("Range")
                String timeStampUpdate = ""+ cursor.getString(cursor.getColumnIndex(Constants.C_UPDATE_TIMESTAMP));

                Calendar calendar = Calendar.getInstance(Locale.getDefault());
                calendar.setTimeInMillis(Long.parseLong(timeStamp));
                String timeAdded = ""+DateFormat.format("dd/MM/YYYY hh:mm:aa", calendar);

                Calendar calendar1 = Calendar.getInstance(Locale.getDefault());
                calendar.setTimeInMillis(Long.parseLong(timeStamp));
                String timeAddedd = ""+DateFormat.format("dd/MM/YYYY hh:mm:aa", calendar1);


                if (imageShow.equals("null")){
                    fullImage.setImageResource(R.drawable.ic_baseline_person_add_24);
                }else {
                    fullImage.setImageURI(Uri.parse(imageShow));
                }

            }while (cursor.moveToNext());
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}