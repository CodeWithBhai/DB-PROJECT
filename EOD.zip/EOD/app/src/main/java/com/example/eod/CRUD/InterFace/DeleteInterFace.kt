package com.example.eod.CRUD.InterFace

interface DeleteInterFace {
    fun getDelete(id:String)
}