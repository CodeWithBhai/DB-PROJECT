package com.example.eod.DATABASEPRO;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.eod.CRUD.FullImageActivity;
import com.example.eod.R;

import java.util.ArrayList;
import java.util.List;

public class AdapterRecord extends RecyclerView.Adapter<AdapterRecord.ViewHolder> {
    Context context;
    ArrayList<ModelRecord> recordList;

    public AdapterRecord(Context context, ArrayList<ModelRecord> recordList) {
        this.context = context;
        this.recordList = recordList;
    }

    @NonNull
    @Override
    public AdapterRecord.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecord.ViewHolder holder, int position) {
        ModelRecord modelRecord = recordList.get(position);
        String id = modelRecord.getId();
        String name = modelRecord.getName();
        String image = modelRecord.getImage();
        String price = modelRecord.getPrice();
        String desc = modelRecord.getBio();
        String addedTime = modelRecord.getAddedTime();
        String updateTime = modelRecord.getUpdateTime();

         holder.nameShow.setText(name);
         holder.descriptionShow.setText(desc);
         holder.priceShow.setText(price);
         holder.imageID.setImageURI(Uri.parse(image));

         if (image.equals("null")){
             holder.imageID.setImageResource(R.drawable.ic_baseline_person_add_24);
         }else {
             holder.imageID.setImageURI(Uri.parse(image));
         }

         holder.imageID.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent(context, FullImageActivity.class);
                 intent.putExtra("RECORD_ID", image);
                 context.startActivity(intent);
             }
         });



    }

    @Override
    public int getItemCount() {
        return recordList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageID;
        TextView nameShow, priceShow, descriptionShow;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageID = itemView.findViewById(R.id.imageID);
            nameShow = itemView.findViewById(R.id.nameShow);
            priceShow = itemView.findViewById(R.id.priceShow);
            descriptionShow = itemView.findViewById(R.id.descriptionShow);

        }
    }
}
