package com.example.eod.CRUD;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.eod.CRUD.Utils.Model;
import com.example.eod.CRUD.Utils.RecordListAdapter;
import com.example.eod.R;
import com.example.eod.databinding.ActivityAllRecordListBinding;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.ArrayList;

public class AllRecordListActivity extends AppCompatActivity{
    ActivityAllRecordListBinding binding;
    ArrayList<Model> modelArrayList = null;
    RecordListAdapter adapter;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         binding = ActivityAllRecordListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        modelArrayList = new ArrayList<>();
        adapter = new RecordListAdapter(this, R.layout.list_row, modelArrayList);
        binding.listRecord.setAdapter(adapter);

        Cursor cursor = CrudMainActivity.sqLiteHelper.getData("SELECT * FROM RECORD");
        modelArrayList.clear();;

        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String price = cursor.getString(2);
            String desc = cursor.getString(3);
            byte[]  image = cursor.getBlob(4);

            modelArrayList.add(new Model(id, name, price ,desc, "", image));
        }
        adapter.notifyDataSetChanged();

        if (modelArrayList.size() == 0){
            Toast.makeText(this, "No Record found...", Toast.LENGTH_SHORT).show();
        }
        binding.listRecord.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //code later
                CharSequence[] charSequences = {"Update", ""};
                AlertDialog.Builder builder = new AlertDialog.Builder(AllRecordListActivity.this);
                builder.setTitle("Choose an action");
                builder.setItems(charSequences, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        if (i == 0){
                            //update
                            Cursor cursor1 = CrudMainActivity.sqLiteHelper.getData("SELECT id FROM RECORD");
                            ArrayList<Integer> arrayList = new ArrayList<Integer>();
                            while (cursor1.moveToNext()){
                                arrayList.add(cursor1.getInt(0));
                            }
                            showDialogUpdate(AllRecordListActivity.this, arrayList.get(position));
                        }if (i == 1){
                            //delete
                            Cursor c = CrudMainActivity.sqLiteHelper.getData("SELECT id FROM RECORD");
                            ArrayList<Integer> arrayId = new ArrayList<Integer>();
                            while (c.moveToNext()){
                                arrayId.add(c.getInt(0));
                            }
                            showDialogDelete(arrayId.get(position));
                        }
                    }
                });
                builder.show();
                return true;
            }
        });
    }

    private void showDialogDelete(int idRecord) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Warning!!");
        builder.setMessage("Are you sure to delete?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    CrudMainActivity.sqLiteHelper.deleteData(idRecord);
                    Toast.makeText(AllRecordListActivity.this, "Delete Successfully!!", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();

    }

    private void showDialogUpdate(Activity activity, final int position){
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.update_dialog_row);
        dialog.setTitle("Update");

        imageView = dialog.findViewById(R.id.imageUpdate);
        EditText name = dialog.findViewById(R.id.updateName);
        EditText desc = dialog.findViewById(R.id.updateDesc);
        EditText price = dialog.findViewById(R.id.updatePrice);
        Button submitDataupdate = dialog.findViewById(R.id.submitDataupdate);

        Cursor cursor = CrudMainActivity.sqLiteHelper.getData("SELECT * FROM RECORD WHERE id="+position);
        modelArrayList.clear();;

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String namee = cursor.getString(1);
            name.setText(namee);
            String pricee = cursor.getString(2);
            price.setText(pricee);
            String descc = cursor.getString(3);
            desc.setText(descc);
            byte[] imagee = cursor.getBlob(4);
            imageView.setImageBitmap(BitmapFactory.decodeByteArray(imagee, 0, imagee.length));

            modelArrayList.add(new Model(id, namee, pricee, descc, "", imagee));
        }

        int width = (int) (activity.getResources().getDisplayMetrics().widthPixels*0.95);
        //set height od dialog

        int height =  (int) (activity.getResources().getDisplayMetrics().heightPixels*0.9);
        dialog.getWindow().setLayout(width, height);
        dialog.show();

        //inupdate dialo click images view to update

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(AllRecordListActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE
                        }, 888);
            }
        });

        submitDataupdate.setOnClickListener(v -> {
            try {
                CrudMainActivity.sqLiteHelper.updateData(
                        name.getText().toString().trim(),
                        price.getText().toString().trim(),
                        desc.getText().toString().trim(),
                        CrudMainActivity.imageViewToByte(imageView),
                        position);

                dialog.dismiss();
                Toast.makeText(getApplicationContext(), "Update successfully!!", Toast.LENGTH_SHORT).show();
            }catch (Exception e){
                e.printStackTrace();
                Log.e("Update error", e.getMessage());
            }
            updateRecordList();
        });

    }

    private void updateRecordList() {
       Cursor cursor = CrudMainActivity.sqLiteHelper.getData(" SELECT * FROM RECORD ");
       modelArrayList.clear();

       while (cursor.moveToNext()){
           int id = cursor.getInt(0);
           String name = cursor.getString(1);
           String price = cursor.getString(2);
           String desc = cursor.getString(3);
           byte[] image = cursor.getBlob(4);

           modelArrayList.add(new Model(id, name, price, desc, "", image));
       }
       adapter.notifyDataSetChanged();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 888){
            if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                //gallery intent
                Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/*");
                startActivityForResult(gallery, 888);
            }
            else {
                Toast.makeText(this, "Don't have permission to access file location", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 888 && resultCode == RESULT_OK){
            Uri imageUrl = data.getData();
            CropImage.activity(imageUrl)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK){
                Uri resultUrl = result.getUri();
                imageView.setImageURI(resultUrl);
            }
            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Exception error = result.getError();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}